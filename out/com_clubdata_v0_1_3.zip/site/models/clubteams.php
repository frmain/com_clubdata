<?php
/**
 * @package     Joomla
 * @subpackage  com_clubdata
 *
 * @copyright   Copyright (C) 2017 vv Bruse Boys. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use SportlinkClubData\ClubData;
use SportlinkClubData\Team;

/**
 * ClubData Model
 *
 */
class ClubDataModelClubteams extends ClubDataModelBase
{
	/**
	 * @var Team[] 
	 */
	protected $teams;
 
	/**
	 * Get the message
	 * @return  string  The message to be displayed to the user
	 */
	public function getTeams()
	{
		if (!isset($this->teams))
		{
			$this->teams = $sportlink->getTeams();
		}
		return $this->teams;
	}
}
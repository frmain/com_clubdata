<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_weblinks
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Routing class from com_clubdata
 *
 * @since  3.3
 */
class ClubDataRouter extends JComponentRouterBase
{
	/**
	 * Build the route for the com_clubdata component
	 *
	 * @todo CHANGE THIS!!!!
	 * 
	 * @param   array  &$query  An array of URL arguments
	 *
	 * @return  array  The URL arguments to use to assemble the subsequent URL.
	 *
	 * @since   3.3
	 */
	public function build(&$query)
	{
	    //index.php?option=com_clubdata&view=team&Itemid=1040&teamcode=133473&league=496569
	    

	    $segments = array();
/*
	    if (isset($query['view']))
	    {
	        $segments[] = $query['view'];
	        unset($query['view']);
	    }
	    if (isset($query['teamcode']))
	    {
	        $segments[] = $query['teamcode'];
	        unset($query['teamcode']);
	    };
	    if (isset($query['league']))
	    {
	        $segments[] = $query['league'];
	        unset($query['league']);
	    };
*/
	    return $segments;
	    

	}

	/**
	 * Parse the segments of a URL.
	 *
	 * @param   array  &$segments  The segments of the URL to parse.
	 *
	 * @return  array  The URL attributes to be used by the application.
	 *
	 * @since   3.3
	 */
	public function parse(&$segments)
	{
	    $vars = array();
	    switch($segments[0])
	    {
	        case 'team':
	            $vars['view'] = 'team';
	            $teamcode = explode(':', $segments[1]);
	            $vars['teamcode'] = (int) $teamcode[0];
	            $league = explode(':', $segments[2]);
	            $vars['league'] = (int) $league[0];
	            break;
	    }
	    return $vars;
	}
	
}


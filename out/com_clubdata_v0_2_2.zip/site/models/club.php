<?php
/**
 * @package     Joomla
 * @subpackage  com_clubdata
 *
 * @copyright   Copyright (C) 2017 vv Bruse Boys. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JLoader::register('ClubDataModelBase', __DIR__ . '/base.php');

use SportlinkClubData\Team;
use SportlinkClubData\ClubMatch;


/**
 * ClubData Model
 *
 */
class ClubDataModelClub extends ClubDataModelBase
{
    /**
	 * @var Team[] 
	 */
	protected $teams;
	
	/**
	 * @var ClubMatch[];
	 */
	protected $nextweekschedule;
 
	/**
	 * @var ClubMatch[];
	 */
	protected $nextweekschedulehome;
	
	/**
	 * @var ClubMatch[];
	 */
	protected $nextweekscheduleaway;
 
    /**
	 * @var ClubMatch[];
	 */
	protected $lastweekresults;
	
	/**
	 * @var ClubMatch[];
	 */
	protected $cancellations;
	
	/**
	 * Get the teams of the club
	 * @return  SportlinkClubData\Team[]  list of clubteams
	 */
	public function getTeams()
	{
		if (!isset($this->teams))
		{
			$this->teams = $this->sportlink->getTeams();
		}
		return $this->teams;
	}
	
	/**
	 * Get the schedule for all teams of the club for the coming week (8 days ahead)
	 *
	 * @return ClubMatch[]
	 */
	public function getNextWeekSchedule()
	{
	    $app = JFactory::getApplication();
	    $homeaway=$app->input->getvar('homeaway');
	    $home = true; $away = true;
	    if ($homeaway=="home") $away = false;
	    if ($homeaway=="away") $home = false;
        $this->nextweekschedule = $this->sportlink->getSchedule(8, null, null, true, "datum", null, $home, $away);
	    return $this->nextweekschedule;
	}
	
	
	/**
	 * Get the results of all teams of the club from last week (7 days back)
	 *
	 * @return ClubMatch[]
	 */
	public function getLastWeekResults()
	{
	    if (!isset($this->lastweekresults))
	    {
	        $this->lastweekresults = $this->sportlink->getResults(7, null, null, null, true, "team");
	    }
	    return $this->lastweekresults;
	}
	
	/**
	 * Get the cancellations of all teams of the club for the next period (30 days ahead from now)
	 *
	 * @return ClubMatch[]
	 */
	public function getCancellations()
	{
	    if (!isset($this->cancellations))
	    {
	        $this->cancellations = $this->sportlink->getCancellations();
	    }
	    return $this->cancellations;
	}
	
	
}
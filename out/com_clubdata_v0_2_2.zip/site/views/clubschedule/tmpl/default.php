<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_clubdata
 *
 * @copyright   Copyright (C) 2017 Bruse Boys
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

if (empty($this->clubschedule)) { ?>
<div class="clubdata-nomatches">
	<?php echo JText::_('COM_CLUBDATA_CLUB_SCHEDULE_NO_MATCHES'); ?>
</div>
<?php 
} 
else 
{ ?>

<div id="clubdata-clubschedule" class="clubdata-clubschedule"> 
	<div class="clubdata-match clubdata-header">
		<div class="clubdata-match-date"><?php echo JText::_('COM_CLUBDATA_MATCH_DATE'); ?></div>
		<div class="clubdata-match-time"><?php echo JText::_('COM_CLUBDATA_MATCH_TIME'); ?></div>
		<div class="clubdata-match-home"><?php echo JText::_('COM_CLUBDATA_MATCH_HOMETEAM'); ?></div>
		<div class="clubdata-match-away"><?php echo JText::_('COM_CLUBDATA_MATCH_AWAYTEAM'); ?></div>
		<div class="clubdata-match-referee"><?php echo JText::_('COM_CLUBDATA_MATCH_REFEREE'); ?></div>
		<div class="clubdata-match-field"><?php echo JText::_('COM_CLUBDATA_MATCH_FIELD'); ?></div>
		<div class="clubdata-match-state"><?php echo JText::_('COM_CLUBDATA_MATCH_STATE'); ?></div>
	</div>
	<?php foreach ($this->clubschedule as $match) { ?>
	<div class="clubdata-match">
		<div class="clubdata-match-date"><?php echo (new JDate($match->wedstrijddatum->format('Y-m-d')))->format('D j M'); ?></div>
		<div class="clubdata-match-time"><?php echo $match->aanvangstijd ?></div>
		<div class="clubdata-match-home"><?php echo $match->thuisteam ?></div>
		<div class="clubdata-match-away"><?php echo $match->uitteam ?></div>
		<div class="clubdata-match-referee"><?php echo $match->scheidsrechter ?></div>
		<div class="clubdata-match-field"><?php echo $match->veld ?></div>
		<div class="clubdata-match-state"><?php echo $match->status ?></div>
	</div>
	
	<?php } ?>
	
</div>
<?php } ?>
<?php 
$document = JFactory::getDocument();
$document->addScriptDeclaration('
	(function($){
		$(document).ready(function() {
            $(".collapse").on("show.bs.collapse", function () {
                $(".collapse.in").collapse("hide");
            });
		});
	}) (jQuery);
');

?>
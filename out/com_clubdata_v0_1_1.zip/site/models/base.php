<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_clubdata
 *
 * @copyright   Copyright (C) 2017 vv Bruse Boys. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use SportlinkClubData\ClubData;

jimport('joomla.application.component.helper');


/**
 * ClubData Model Base class
 *
 */
class ClubDataModelBase extends JModelLegacy
{
	
	/**
	 * @var ClubData $sportlink
	 */
	protected $sportlink;
	
	public function __construct($config)
	{
		parent::__construct($config);
		
		/**
		 * @var string $key
		 */
		$key = JComponentHelper::getParams('com_clubdata')->get('clientid');
		$this->sportlink = new ClubData($key);
	}
	
}
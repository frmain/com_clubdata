<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_weblinks
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Routing class from com_clubdata
 *
 * @since  3.3
 */
class ClubDataRouter extends JComponentRouterBase
{
	/**
	 * Build the route for the com_clubdata component
	 *
	 * @todo CHANGE THIS!!!!
	 * 
	 * @param   array  &$query  An array of URL arguments
	 *
	 * @return  array  The URL arguments to use to assemble the subsequent URL.
	 *
	 * @since   3.3
	 */
	public function build(&$query)
	{
	    //index.php?option=com_clubdata&view=team&Itemid=1040&teamcode=133473&league=496569
	    

	    $segments = array();
	    
		// Get a menu item based on Itemid or currently active
		//$params = JComponentHelper::getParams('com_newsfeeds');
		//$advanced = $params->get('sef_advanced_link', 0);

	    
	    /*
		if (empty($query['Itemid']))
		{
			$menuItem = $this->menu->getActive();
		}
		else
		{
			$menuItem = $this->menu->getItem($query['Itemid']);
		}

		$mView = (empty($menuItem->query['view'])) ? null : $menuItem->query['view'];
		$mId   = (empty($menuItem->query['teamcode'])) ? null : $menuItem->query['teamcode'];

		if (isset($query['view']))
		{
			$view = $query['view'];

			if (empty($query['Itemid']) || empty($menuItem) || $menuItem->component != 'com_clubdata')
			{
				$segments[] = $query['view'];
			}

			unset($query['view']);
		}

		// Are we dealing with a clubdata that is attached to a menu item?
		if (isset($query['view']) && ($mView == $query['view']) and (isset($query['teamcode'])) and ($mId == (int) $query['teamcode']))
		{
			unset($query['view']);
			unset($query['teamcode']);
			unset($query['league']);

			return $segments;
		}

		if (isset($view) and ($view == 'team'))
		{
			if ($mId != (int) $query['id'] || $mView != $view)
			{
				if ($view == 'newsfeed' && isset($query['catid']))
				{
					$catid = $query['catid'];
				}
				elseif (isset($query['id']))
				{
					$catid = $query['id'];
				}

				$menuCatid = $mId;
				$categories = JCategories::getInstance('Newsfeeds');
				$category = $categories->get($catid);

				if ($category)
				{
					$path = $category->getPath();
					$path = array_reverse($path);

					$array = array();

					foreach ($path as $id)
					{
						if ((int) $id == (int) $menuCatid)
						{
							break;
						}

						if ($advanced)
						{
							list($tmp, $id) = explode(':', $id, 2);
						}

						$array[] = $id;
					}

					$segments = array_merge($segments, array_reverse($array));
				}

				if ($view == 'newsfeed')
				{
					if ($advanced)
					{
						list($tmp, $id) = explode(':', $query['id'], 2);
					}
					else
					{
						$id = $query['id'];
					}

					$segments[] = $id;
				}
			}

			unset($query['id']);
			unset($query['catid']);
		}

		if (isset($query['layout']))
		{
			if (!empty($query['Itemid']) && isset($menuItem->query['layout']))
			{
				if ($query['layout'] == $menuItem->query['layout'])
				{
					unset($query['layout']);
				}
			}
			else
			{
				if ($query['layout'] == 'default')
				{
					unset($query['layout']);
				}
			}
		}

		$total = count($segments);

		for ($i = 0; $i < $total; $i++)
		{
			$segments[$i] = str_replace(':', '-', $segments[$i]);
		}
*/
		/*
	    if (isset($query['view']))
	    {
	        $segments[] = $query['view'];
	        unset($query['view']);
	    }
	    if (isset($query['teamcode']))
	    {
	        $segments[] = $query['teamcode'];
	        unset($query['teamcode']);
	    };
	    if (isset($query['league']))
	    {
	        $segments[] = $query['league'];
	        unset($query['league']);
	    };
	    */

	    return $segments;
	    

	}

	/**
	 * Parse the segments of a URL.
	 *
	 * @param   array  &$segments  The segments of the URL to parse.
	 *
	 * @return  array  The URL attributes to be used by the application.
	 *
	 * @since   3.3
	 */
	public function parse(&$segments)
	{
	    $vars = array();
	    switch($segments[0])
	    {
	        case 'team':
	            $vars['view'] = 'team';
	            $teamcode = explode(':', $segments[1]);
	            $vars['teamcode'] = (int) $teamcode[0];
	            $league = explode(':', $segments[2]);
	            $vars['league'] = (int) $league[0];
	            break;
	    }
	    return $vars;
	}
	
}


<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_clubdata
 *
 * @copyright   Copyright (C) 2017 vv Bruse Boys. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

require_once JPATH_ADMINISTRATOR . '/components/com_clubdata/vendor/autoload.php';

use SportlinkClubData\ClubData;
use SportlinkClubData\Club;
use SportlinkClubData\Team;

jimport('joomla.application.component.helper');


/**
 * ClubData Model Base class
 *
 */
class ClubDataModelBase extends JModelLegacy
{
	
	/**
	 * @var ClubData $sportlink
	 */
	protected $sportlink;
	
	/**
	 * @var Club
	 */
	protected $club;
	
	/**
	 * @var Team[]
	 */
	protected $teams;
	
	public function __construct($config)
	{
		parent::__construct($config);
		
		/**
		 * @var string $key
		 */
		$key = JComponentHelper::getParams('com_clubdata')->get('clientid');
		$this->sportlink = new ClubData($key);
	}
	
	/**
	 * Get the club
	 *
	 * @return Club  The club object
	 */
	public function getClub()
	{
	    if (!isset($this->club))
	    {
	        $this->club = new Club($this->sportlink);
	    }
	    return $this->club;
	}
	
	/**
	 * Get the teams of the club
	 * @return  SportlinkClubData\Team[]  list of clubteams
	 */
	public function getTeams()
	{
	    if (!isset($this->teams))
	    {
	        $this->teams = $this->sportlink->getTeams();
	    }
	    return $this->teams;
	}
	
	
	
}
<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');


/**
 * Raw html View class for the ClubData Component (for calling ajax)
 * Display league results
 */
class ClubDataViewClubCancellations extends JViewLegacy
{

	/**
	 * @var SportlinkClubData\ClubMatch[]
	 */
	protected $clubcancellations;
	
	/**
	 * Overriding JView display method
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 * @return  void
	 */
	function display($tpl = null)
	{
	    $this->clubcancellations = $this->get('Cancellations');
		
		parent::display($tpl);
	}
	
}

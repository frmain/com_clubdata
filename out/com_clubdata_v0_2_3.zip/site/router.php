<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_clubdata
 */

defined('_JEXEC') or die;

/**
 * Routing class from com_clubdata
 *
 * @since  3.3
 */
class ClubDataRouter extends JComponentRouterView
{
    protected $noIDs = false;
    
    /**
     * ClubData Component router constructor
     *
     * @param   JApplicationCms  $app   The application object
     * @param   JMenu            $menu  The menu object to work with
     */
    public function __construct($app = null, $menu = null)
    {
        $params = JComponentHelper::getParams('com_clubdata');
        $this->noIDs = (bool) $params->get('sef_ids');
        
        $team = new JComponentRouterViewconfiguration('team');
        $team->setKey('teamcode');
        $this->registerView($team);

        parent::__construct($app, $menu);
        
        $this->attachRule(new JComponentRouterRulesMenu($this));
        $this->attachRule(new JComponentRouterRulesStandard($this));
        $this->attachRule(new JComponentRouterRulesNomenu($this));
    }
    
    
    /**
     * Method to get the segment(s) for a team
     *
     * @param   string  $id     teamcode of the team to retrieve the segments for
     * @param   array   $query  The request that is built right now
     *
     * @return  array|string  The segments of this item
     */
    public function getTeamSegment($id, $query)
    {

        return array('133474:bruseboys-1');
        
        
        /*
        $category = JCategories::getInstance($this->getName())->get($id);
        
        if ($category)
        {
            $path = array_reverse($category->getPath(), true);
            $path[0] = '1:root';
            
            if ($this->noIDs)
            {
                foreach ($path as &$segment)
                {
                    list($id, $segment) = explode(':', $segment, 2);
                }
            }
            
            return $path;
        }
        
        return array();
        */
    }

    /**
     * Method to get the segment(s) for a team
     *
     * @param   string  $segment  Segment of the contact to retrieve the Teamcode for
     * @param   array   $query    The request that is parsed right now
     *
     * @return  mixed   The id of this item or false
     */
    public function getTeamTeamcode($segment, $query)
    {
        /*
        if ($this->noIDs)
        {
            $db = JFactory::getDbo();
            $dbquery = $db->getQuery(true);
            $dbquery->select($dbquery->qn('id'))
            ->from($dbquery->qn('#__contact_details'))
            ->where('alias = ' . $dbquery->q($segment))
            ->where('catid = ' . $dbquery->q($query['id']));
            $db->setQuery($dbquery);
            
            return (int) $db->loadResult();
        }
        */
        return (int) $segment;
    }
    
    
}

/**
 * ClubData router functions
 *
 * These functions are proxys for the new router interface
 * for old SEF extensions.
 *
 * @param   array  &$query  An array of URL arguments
 *
 * @return  array  The URL arguments to use to assemble the subsequent URL.
 *
 * @deprecated  4.0  Use Class based routers instead
 */
function ClubDataBuildRoute(&$query)
{
	$app = JFactory::getApplication();
	$router = new ClubDataRouter($app, $app->getMenu());

	return $router->build($query);
}

/**
 * ClubData router functions
 *
 * These functions are proxys for the new router interface
 * for old SEF extensions.
 *
 * @param   array  $segments  The segments of the URL to parse.
 *
 * @return  array  The URL attributes to be used by the application.
 *
 * @deprecated  4.0  Use Class based routers instead
 */
function ClubDataParseRoute($segments)
{
	$app = JFactory::getApplication();
	$router = new ClubDataRouter($app, $app->getMenu());

	return $router->parse($segments);
}

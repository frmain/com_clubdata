<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_clubdata
 *
 * @copyright   Copyright (C) 2017 vv Bruse Boys. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use SportlinkClubData\ClubData;
use SportlinkClubData\Team;
use SportlinkClubData\League;
use SportlinkClubData\LeaguePosition;
use SportlinkClubData\OptionPeriod;
use SportlinkClubData\Club;
use SportlinkClubData\TeamPlayer;
use SportlinkClubData\LeagueMatch;

/**
 * ClubData Model
 *
 */
class ClubDataModelLeagueSchedule extends ClubDataModelBase
{
	
	/**
	 * @var string
	 */
	private $leagueid = null;
	
	/**
	 * @var League
	 */
	protected $league=null;
	
	/**
	 * @var LeagueMatch[]
	 */
	protected $leagueschedule=null;
	
	/**
	 * @var LeagueMatch[]
	 */
	protected $ownleagueschedule=null;
	
	/**
	 * @var LeagueMatch[]
	 */
	protected $nextweekleagueschedule=null;
	
	/**
	 * Get the league
	 *
	 * @return League  The league object
	 * @throws Exception if league does not exist
	 */
	public function getLeague()
	{
		if (!isset($this->league))
		{
			$app = JFactory::getApplication();
			$this->leagueid = $app->input->get('league',null);
			try {
				$this->league = new League($this->sportlink, $this->leagueid);
				//$this->league->populate();
			} catch (Exception $e) {
				throw new Exception(JText::sprintf('COM_CLUBDATA_LEAGUE_NOTFOUND', $this->leagueid), 404);
			}
		}
		return $this->league;
	}
	
	/**
	 * Get the league schedule for max 365 days ahead
	 *
	 * @return LeagueMatch[]
	 * @throws Exception if league does not exist
	 */
	public function getLeagueSchedule()
	{
		if (!isset($this->leagueschedule))
		{
			try {
				$this->leagueschedule = $this->getLeague()->getMatchSchedule(false, 365);
			} catch (Exception $e) {
				throw new Exception(JText::sprintf('COM_CLUBDATA_LEAGUE_NOTFOUND', $this->leagueid), 404);
			}
		}
		return $this->leagueschedule;
	}

	/**
	 * Get the leagueschedule for the coming weeks (14 days ahead) 
	 *
	 * @return LeagueMatch[]
	 * @throws Exception if league does not exist
	 */
	public function getNextWeekLeagueSchedule()
	{
		if (!isset($this->nextweekleagueschedule))
		{
			try {
				$this->nextweekleagueschedule = $this->getLeague()->getMatchSchedule(false, 14);
			} catch (Exception $e) {
				throw new Exception(JText::sprintf('COM_CLUBDATA_LEAGUE_NOTFOUND', $this->leagueid), 404);
			}
		}
		return $this->nextweekleagueschedule;
	}
	
	/**
	 * Get the own leagueschedule for max 365 days ahead 
	 *
	 * @return LeagueMatch[]
	 * @throws Exception if league does not exist
	 */
	public function getOwnLeagueSchedule()
	{
		if (!isset($this->ownleagueschedule))
		{
			try {
				$this->ownleagueschedule = $this->getLeague()->getMatchSchedule(true, 365);
			} catch (Exception $e) {
				throw new Exception(JText::sprintf('COM_CLUBDATA_LEAGUE_NOTFOUND', $this->leagueid), 404);
			}
		}
		return $this->ownleagueschedule;
	}
	
}
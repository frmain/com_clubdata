<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_clubdata
 *
 * @copyright   Copyright (C) 2017 Bruse Boys
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
<h1><?php echo JText::_('COM_CLUBDATA_TEAM_TITLE'), JText::_('COM_CLUBDATA_ENUMERATION'), $this->club->clubnaam, ' ', $this->team->teamnaam; ?></h1>

<div class="clubdata-teamdata"> 
	<?php if (isset($this->team->teamfoto)) { ?>
	<div class="clubdata-team-photo">
		<img class="clubdata-team-img" src="data:image/png;base64, <?php echo $this->team->teamfoto; ?>" alt="<?php echo $this->club->clubnaam, ' ', $this->team->teamnaam ?>" />
	</div>
	<?php } ?>


	<div class="clubdata-category">
		<span><?php echo JText::_('COM_CLUBDATA_TEAM_CATEGORY'), JText::_('COM_CLUBDATA_ENUMERATION'); ?></span>
		<span><?php echo $this->team->geslacht, ', ', $this->team->categorie ?></span>
	</div>
	<?php if (isset($this->team->omschrijving)) { ?>
	<div class="clubdata-description">
		<span><?php echo JText::_('COM_CLUBDATA_TEAM_DESCRIPTION'), JText::_('COM_CLUBDATA_ENUMERATION'); ?></span>
		<span><?php echo $this->team->omschrijving ?></span>
	</div>
	<?php } ?>
</div>
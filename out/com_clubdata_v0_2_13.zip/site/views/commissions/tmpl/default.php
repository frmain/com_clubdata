<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_clubdata
 *
 * @copyright   Copyright (C) 2018 Bruse Boys
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::stylesheet('com_clubdata/clubdata.css', array(), true);

?>

<div class="clubdatacommissions">
	<div class="col-md-12">
		<h1><?php echo JText::_('COM_CLUBDATA_COMMISSIONS_TITLE'); ?></h1>
        <p class="clubdata-infotext"><?php echo JText::_('COM_CLUBDATA_COMMISSIONS_DESCRIPTION'); ?></p>
    	<?php 
    	// 2-column-layout
    	$cols=2;
    	$cnt = 0;
    	foreach ($this->commissions as $commission) { 
    	    $cnt++;
    	    if ($cnt % $cols == 1) { echo '<div class="clubdata-commission-row">'; }	?>
            		<div class="clubdata-commission">
            			<?php 
            			 $this->commission = &$commission;
            			 echo $this->loadTemplate('commission');
            			?>
            		</div>
			<?php
			if ($cnt % $cols == 0) { echo "</div>"; }	
    	} 
		if ($cnt % $cols == 1) { echo "</div>"; }
		?>
	</div>
</div>
